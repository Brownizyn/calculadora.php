<?php
    // variaveis
    $x = $_POST['x'];
    $y = $_POST['y'];
    $operacao = $_POST['operacao'];

    // calculo baseado em if
    switch ($operacao) {
        case 'soma':
            echo 'Resulatado da soma: ' . $x + $y;
            break;
        case 'subtracao':
            echo 'Resultado da subtração: ' . $x - $y; 
            break;
        case 'multiplicacao':
            echo 'Resultado da multiplicação: ' . $x * $y;
            break;
        case 'divisao':
            echo 'Resultado da divisão: ' . $x / $y;
            break;
        default:
            echo 'Operação não realisada';
            break;
    }
?>
